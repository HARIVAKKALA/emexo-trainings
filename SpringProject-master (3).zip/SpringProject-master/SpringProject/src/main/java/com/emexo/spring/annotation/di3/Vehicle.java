package com.emexo.spring.annotation.di3;

public interface Vehicle {
    void engine();
}
