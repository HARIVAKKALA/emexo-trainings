package com.emexo.service;

import com.emexo.entity.Ticket;

public interface TicketService {
    Iterable<Ticket> listTickets();
}


