package com.emexo.service;

import com.emexo.entity.Release;

public interface ReleaseService {
    Iterable<Release> listReleases();
}


