package com.emexo.service;

import com.emexo.entity.Release;

import java.util.List;

public interface ReleaseService {
    List<Release> listReleases();
}


