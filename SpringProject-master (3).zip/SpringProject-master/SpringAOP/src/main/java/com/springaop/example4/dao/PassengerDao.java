package com.springaop.example4.dao;

import com.springaop.example4.model.Passenger;

public interface PassengerDao {
    Passenger getPassenger(int id);
}
