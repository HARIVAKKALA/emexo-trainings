package com.springaop.example2.dao;

import com.springaop.example2.model.Passenger;

public interface PassengerDao {
    Passenger getPassenger(int id);
    void getPassenger1();
}
