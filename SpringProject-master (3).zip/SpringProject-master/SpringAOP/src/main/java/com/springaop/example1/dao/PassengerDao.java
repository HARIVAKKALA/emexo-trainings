package com.springaop.example1.dao;

import com.springaop.example1.model.Passenger;

public interface PassengerDao {
    Passenger getPassenger(int id);
}
