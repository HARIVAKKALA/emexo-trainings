package com.emexo.spring.integration.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringIntegrationExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
